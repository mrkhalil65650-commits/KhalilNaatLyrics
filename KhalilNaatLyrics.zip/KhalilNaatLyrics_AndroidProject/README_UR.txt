یہ Android APK بنانے کا source project ہے، APK فائل خود نہیں۔

موبائل سے build کرنے کا طریقہ:
1) GitHub پر repository بنائیں اور اس ZIP کے اندر کی تمام فائلیں upload کریں۔
2) Actions tab کھولیں، Build Khalil Naat Lyrics APK workflow منتخب کریں، Run workflow دبائیں۔
3) build کامیاب ہو تو Artifacts سے KhalilNaatLyrics-debug-apk ZIP ڈاؤن لوڈ کریں، extract کریں اور app-debug.apk انسٹال کریں۔

اہم: یہ test build ہے، compilation اس ماحول میں نہیں ہوئی۔ آن لائن cloud backup/login ابھی شامل نہیں۔ uninstall ہونے پر مقامی ڈیٹا ضائع ہو سکتا ہے؛ اہم نعتوں کی backup JSON الگ رکھیں۔
